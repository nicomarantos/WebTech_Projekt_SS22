package htw.berlin.webtech.Plantast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantastApplicationTests {

	@Test
	void contextLoads() {
	}

}

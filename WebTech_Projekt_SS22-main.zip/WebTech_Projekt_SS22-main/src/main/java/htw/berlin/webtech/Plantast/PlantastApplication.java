package htw.berlin.webtech.Plantast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantastApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlantastApplication.class, args);
	}

}
